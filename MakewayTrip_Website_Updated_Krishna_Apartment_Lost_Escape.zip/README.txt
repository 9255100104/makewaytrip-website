MAKEWAY TRIP WEBSITE — UPDATED PACKAGE

Changes in this package:
- Khatu Shyam property is listed only as “Krishna Apartment”.
- Removed the separate “Hotel Barbarik (Krishna Resorts)” card and enquiry dropdown option.
- Replaced The Lost Escape placeholder image with the supplied original front-view photo.
- Added original The Lost Escape room, mountain-view and exterior photos to the property gallery.
- Retained the Hindi/English toggle and WhatsApp enquiry form.

Files:
- index.html: website structure and property listings
- style.css: responsive styling
- app.js: Hindi/English toggle, mobile menu, WhatsApp enquiry form
- admin.html: admin landing page (secure admin login is not activated)
- images/: property photos, including supplied The Lost Escape originals

Important:
- This ZIP has been updated locally; it has NOT been deployed to Cloudflare or uploaded to GitHub.
- Admin login/database are not yet implemented.
- After uploading, test all images, mobile layout and WhatsApp enquiry flow on the live domain.
